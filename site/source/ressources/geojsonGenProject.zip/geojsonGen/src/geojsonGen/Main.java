package geojsonGen;

import java.util.Random;

public class Main {
		
	public static void main(String[] args) {
		if(args.length < 1){
			System.out.println("Argument needed: How many points do you want?\n java -jar geoJsonTestGenerator n");
			return;
		}
		
		float w = (float) -1.90;
		float s = (float) 48.02;
		float e = (float) -1.40;
		float n = (float) 48.20;
		
		int it = Integer.parseInt(args[0]);
		int maxValue = 9;
		
		Random rand =new Random();
		String geoJson = "";
				
		for(int i = 0; i < it; i++){
			float randLatitude = n + rand.nextFloat() * (s - n);
			float randLongitude = w + rand.nextFloat() * (e - w	);
			String curr = "{\"type\": \"Feature\",\"properties\": {\"name\": \"test"+i+"\", \"value\": "+rand.nextInt(maxValue)+"},\"geometry\": {\"type\": \"Point\",\"coordinates\": ["+randLongitude+","+randLatitude+"]}}";
			geoJson = geoJson + curr;
			if (i < it - 1){
				geoJson = geoJson + ",";
			}
		}
		System.out.println(geoJson);
	}
}
